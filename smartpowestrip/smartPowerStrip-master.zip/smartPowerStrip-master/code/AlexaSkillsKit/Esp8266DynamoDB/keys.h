#ifndef KEYS_H_
#define KEYS_H_

extern const char* awsKeyID;  // Declare these variables to 
extern const char* awsSecKey; // be accessible by the sketch

#endif
