#include "keys.h"

/* Do not share your AWS keys with anyone, it is reccomended to create a dedicated user with restricted permissions, do not use your root account.
If you accidentally push your keys online disable them immediatly from the AWS IAM console (https://console.aws.amazon.com/iam/home) 

Insert your keys and rename file Key.cpp before flashing
*/

//const char* awsKeyID = "your AWS access key ID here";
//const char* awsSecKey = "awsSecKeyHere";
